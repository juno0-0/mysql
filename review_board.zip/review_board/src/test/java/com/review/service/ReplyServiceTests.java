package com.review.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.review.domain.Criteria;
import com.review.domain.ReplyPageDTO;
import com.review.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyServiceTests {
	@Setter(onMethod_=@Autowired)
	private ReplyService service;
	
	@Test
	public void testRemove() {
		service.remove(17L);
	}
	
//	@Test
//	public void testModify() {
//		ReplyVO reply = service.get(17L);
//		reply.setReply("변경테스트");
//		service.modify(reply);
//		log.info(service.get(17L));
//	}
	
//	@Test
//	public void testGetList() {
//		Criteria cri = new Criteria();
//		ReplyPageDTO dto = service.getList(cri, 12L);
//		dto.getList().forEach(reply -> log.info(reply));
//		log.info(dto.getReplyCnt());
//	}
	
//	@Test
//	public void testGet() {
//		log.info(service.get(17L));
//	}
	
//	@Test
//	public void testInsert() {
//		ReplyVO reply = new ReplyVO();
//		reply.setReply("ㅎㅇ?");
//		reply.setReplyer("me");
//		reply.setBno(12L);
//		
//		log.info(service.register(reply));
//	}
	
//	@Test
//	public void test() {
//		log.info("Test");
//	}
}
