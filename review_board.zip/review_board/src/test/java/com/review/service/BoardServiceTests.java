package com.review.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.review.domain.BoardVO;
import com.review.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTests {
	@Setter(onMethod_=@Autowired)
	private BoardService service;
	
//	@Test
//	public void testGetListWithPaging() {
//		Criteria cri = new Criteria(2, 10);
//		service.getListWithPaging(cri).forEach(board -> log.info(board));
//	}
	
//	@Test
//	public void testRemove() {
//		service.remove(7L);
//	}
	
//	@Test
//	public void testModify() {
//		BoardVO board = service.get(5L);
//		board.setTitle("Change Test");
//		board.setContent("Change Test");
//		board.setWriter("Change Test");
//		
//		service.modify(board);
//	}
	
//	@Test
//	public void testRegister() {
//		BoardVO board = new BoardVO();
//		board.setTitle("service test");
//		board.setContent("service test");
//		board.setWriter("service test");
//		service.register(board);
//	}
	
	@Test
	public void testGet() {
		log.info(service.get(3L));
	}
	
//	@Test
//	public void testList() {
//		service.list().forEach(board -> log.info(board));
//	}
}
