package com.review.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.review.domain.Criteria;
import com.review.domain.ReplyVO;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	@Setter(onMethod_=@Autowired)
	private ReplyMapper mapper;
	
	@Test
	public void testGetTotal() {
		log.info(mapper.getTotal(14L));
	}
	
//	@Test
//	public void testGetListWithPaging() {
//		Criteria cri = new Criteria(2, 10);
//		mapper.getListWithPaging(cri, 14L).forEach(reply -> log.info(reply));
//	}
	
//	@Test
//	public void testDelete() {
//		mapper.delete(2L);
//		log.info(mapper.read(2L));
//	}
	
//	@Test
//	public void testUpdate() {
//		ReplyVO reply = mapper.read(2L);
//		reply.setReply("수정테스트2");
//		mapper.update(reply);
//		log.info(mapper.read(2L));
//	}
	
//	@Test
//	public void testRead() {
//		log.info(mapper.read(2L));
//	}
	
//	@Test
//	public void testInsert() {
//		ReplyVO reply = new ReplyVO();
//		reply.setBno(14L);
//		reply.setReply("테스트댓글2");
//		reply.setReplyer("나야");
//		
//		mapper.insert(reply);
//	}
	
//	@Test
//	public void test() {
//		log.info("테스트");
//	}
}
