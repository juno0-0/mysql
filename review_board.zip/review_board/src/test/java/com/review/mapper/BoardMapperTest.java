package com.review.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.review.domain.BoardVO;
import com.review.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTest {
	@Setter(onMethod_=@Autowired)
	
	private BoardMapper mapper;
	
	@Test
	public void testGetListWithPaging() {
		Criteria cri = new Criteria(2, 10);
		mapper.getListWithPaging(cri).forEach(board -> log.info(board));
	}
	
//	@Test
//	public void testGetListWithPaging() {
//		Criteria cri = new Criteria(2, 10);
//		cri.setType("T");
//		cri.setKeyword("테스트");
//		List<BoardVO> list = mapper.getListWithPaging(cri);
//		list.forEach(board -> log.info(board));
//	}
	
//	@Test
//	public void testUpdate() {
//		BoardVO board = mapper.read(3L);
//		log.info(board);
//		board.setTitle("change");
//		board.setContent("change");
//		board.setWriter("change");
//		mapper.update(board);
//		log.info(mapper.read(3L));
//	}
	
//	@Test
//	public void testDelete() {
//		mapper.delete(14L);
//	}
	
//	@Test
//	public void testGetTotal() {
//		log.info(mapper.getTotal());
//	}
	
//	@Test
//	public void testInsertSelectKey_bno() {
//		BoardVO board = new BoardVO();
//		board.setTitle("hi");
//		board.setContent("hi");
//		board.setWriter("hi");
//		
//		mapper.insert(board);
//		log.info(board);
//	}
	
//	@Test
//	public void testGetList() {
//		mapper.getList().forEach(board -> log.info(board));
//	}
	
//	@Test
//	public void testInsert() {
//		BoardVO board = new BoardVO();
//		board.setTitle("hi");
//		board.setContent("hi");
//		board.setWriter("hi");
//		
//		mapper.insert(board);
//		log.info(board);
//	}
}
