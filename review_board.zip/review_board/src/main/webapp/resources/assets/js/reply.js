/**
 * 
 */

var replyService = (function(){
	function add(reply, callback, error){
		console.log("????");
		$.ajax({
			type: "post",
			url: "/replies/new",
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){
					callback(result);
				}
			},
			error: function(xhr, status, err){
				if(error){
					error(err);
				}
			}
		});
	}
	
	function getList(reply, callback, error){
		console.log("안들어옴?");
		var bno = reply.bno;
		var page = reply.page || 1;
		
		$.getJSON("/replies/pages/"+bno+"/"+page+".json",
				function(data){
					if(callback){
						callback(data.replyCnt, data.list);
					}
				})
			.fail(function(xhr, status, err){
				if(error){
					error(err);
				}
			})
		
	}
	
	function displayTime(timeValue){
		var today = new Date();
		var replyTime = new Date(timeValue);
		var gap = today.getTime() - replyTime.getTime();
		
		if(gap < 24 * 60 * 60 * 1000){
			var hh = replyTime.getHours();
			var mi = replyTime.getMinutes();
			var ss = replyTime.getSeconds();
			
			return [(hh > 9 ? '' : '0') + hh, (mi > 9 ? '' : '0') + mi, (ss > 9 ? '' : '0') + ss].join(' : ');
		}else{
			var yy = replyTime.getFullYead();
			var mm = replyTime.getMonth() + 1;
			var dd = replyTime.getDate();
			
			return [yy, (mm > 9 ? '' : '0') + mm, dd].join(' - ');
		}
	}
	
	function get(rno, callback, error){
		$.getJSON("/replies/"+rno+".json", function(reply){
			if(callback){
				callback(reply);
			}
		}).fail(function(xhr, status, err){
			if(error){
				error(err);
			}
		})
	}
	
	function remove(rno, callback, error){
		console.log("여기 테스트");
		$.ajax({
			type: "delete",
			url: "/replies/"+rno,
			success: function(result){
				if(callback){
					callback(result);
				}
			},
			error: function(xhr, status, err){
				if(error){
					error(err);
				}
			}
		});
	}
	
	function modify(reply, callback, error){
		$.ajax({
			type: "patch",
			url: "/replies/"+reply.rno,
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){
					callback(result);
				}
			},
			error: function(xhr, status, err){
				if(error){
					error(err);
				}
			}
			
		});
	}
	
	return {add: add, getList: getList, displayTime: displayTime, get: get, remove: remove, modify: modify};
	
})();