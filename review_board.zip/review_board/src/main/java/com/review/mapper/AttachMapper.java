package com.review.mapper;

import java.util.List;

import com.review.domain.AttachVO;

public interface AttachMapper {
	public void insert(AttachVO attach);
	public void delete(String uuid);
	public void deleteAll(Long bno);
	public List<AttachVO> findByBno(Long bno);
	public List<AttachVO> getOldFiles();
}
