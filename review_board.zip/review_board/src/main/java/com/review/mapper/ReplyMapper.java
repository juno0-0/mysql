package com.review.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.review.domain.Criteria;
import com.review.domain.ReplyVO;

public interface ReplyMapper {
	public int insert(ReplyVO reply);
	public ReplyVO read(Long rno);
	public List<ReplyVO> getListWithPaging(@Param("cri") Criteria cri, @Param("bno") Long bno);
	public int delete(Long rno);
	public int update(ReplyVO reply);
	public int getTotal(Long bno);
}
