package com.review.service;

import java.util.List;

import com.review.domain.Criteria;
import com.review.domain.ReplyPageDTO;
import com.review.domain.ReplyVO;

public interface ReplyService {
	public int register(ReplyVO reply);
	public ReplyVO get(Long rno);
	public ReplyPageDTO getList(Criteria cri, Long bno);
	public int remove(Long rno);
	public int modify(ReplyVO reply);
}
