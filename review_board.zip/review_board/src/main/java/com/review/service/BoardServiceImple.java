package com.review.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.review.domain.AttachVO;
import com.review.domain.BoardVO;
import com.review.domain.Criteria;
import com.review.mapper.AttachMapper;
import com.review.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class BoardServiceImple implements BoardService{
	private BoardMapper mapper;
	private AttachMapper a_mapper;

	@Override
	public List<BoardVO> list() {
		return mapper.getList();
	}

	@Override
	public void register(BoardVO board) {
		mapper.insertSelectKey_bno(board);
		List<AttachVO> attachList = board.getAttachList();
		if(attachList == null || attachList.size() <= 0) {
			return;
		}
		attachList.forEach(attach -> {
			attach.setBno(board.getBno());
			a_mapper.insert(attach);
		});
	}

	@Override
	public BoardVO get(long bno) {
		return mapper.read(bno);
	}

	@Override
	public void remove(long bno) {
		mapper.delete(bno);
	}

	@Override
	public boolean modify(BoardVO board) {
		a_mapper.deleteAll(board.getBno());
		boolean modifyResult = mapper.update(board) == 1;
		if(modifyResult && board.getAttachList() != null) {
			if(board.getAttachList().size() != 0) {
				board.getAttachList().forEach(attach -> {
					attach.setBno(board.getBno());
					a_mapper.insert(attach);
				});
			}
		}
		return modifyResult;
	}

	@Override
	public int getTotal(Criteria cri) {
		return mapper.getTotal(cri);
	}

	@Override
	public List<BoardVO> getListWithPaging(Criteria cri) {
		cri.setStartNum((cri.getPageNum() - 1) * 10);
		return mapper.getListWithPaging(cri);
	}

	@Override
	public List<AttachVO> getAttachList(Long bno) {
		return a_mapper.findByBno(bno);
	}
}
