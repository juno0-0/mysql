package com.review.service;

import org.springframework.stereotype.Service;

import com.review.domain.Criteria;
import com.review.domain.ReplyPageDTO;
import com.review.domain.ReplyVO;
import com.review.mapper.BoardMapper;
import com.review.mapper.ReplyMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ReplyServiceImple implements ReplyService{
	private ReplyMapper mapper;
	private BoardMapper b_mapper;

	@Override
	public int register(ReplyVO reply) {
		b_mapper.updateReplyCnt(reply.getBno(), 1);
		return mapper.insert(reply);
	}

	@Override
	public ReplyVO get(Long rno) {
		return mapper.read(rno);
	}

	@Override
	public ReplyPageDTO getList(Criteria cri, Long bno) {
		cri.setStartNum((cri.getPageNum() - 1) * 10);
		return new ReplyPageDTO(mapper.getTotal(bno), mapper.getListWithPaging(cri, bno));
	}

	@Override
	public int remove(Long rno) {
		b_mapper.updateReplyCnt(mapper.read(rno).getBno(), -1);
		return mapper.delete(rno);
	}

	@Override
	public int modify(ReplyVO reply) {
		return mapper.update(reply);
	}
}
