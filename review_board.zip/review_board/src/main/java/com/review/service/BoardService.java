package com.review.service;

import java.util.List;

import com.review.domain.AttachVO;
import com.review.domain.BoardVO;
import com.review.domain.Criteria;

public interface BoardService {
	public List<BoardVO> list();
	public List<BoardVO> getListWithPaging(Criteria cri);
	public void register(BoardVO board);
	public BoardVO get(long bno);
	public void remove(long bno);
	public boolean modify(BoardVO board);
	public int getTotal(Criteria cri);
	public List<AttachVO> getAttachList(Long bno);
}
