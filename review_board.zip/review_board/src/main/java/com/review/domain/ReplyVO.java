package com.review.domain;

import lombok.Data;

@Data
public class ReplyVO {
	private long rno;
	private long bno;
	private String reply;
	private String replyer;
	private String replyDate;
	private String updateDate;
}
